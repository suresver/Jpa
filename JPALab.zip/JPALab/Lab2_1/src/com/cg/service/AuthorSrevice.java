package com.cg.service;

import java.util.List;

import com.cg.entities.Author;

public interface AuthorSrevice {
	public Author getById(int id);
	public void addAuthor(Author author);
	public void updateAuthor(Author author);
	public void deleteAuthor(Author author);
	public List<Author> getAllAuthors();
}
