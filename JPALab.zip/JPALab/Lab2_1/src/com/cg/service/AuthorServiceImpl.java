package com.cg.service;

import java.util.List;

import com.cg.dao.AuthorDAO;
import com.cg.dao.AuthorDAOImpl;
import com.cg.entities.Author;

public class AuthorServiceImpl implements AuthorSrevice {
     
	AuthorDAO dao=new AuthorDAOImpl();
	@Override
	public Author getById(int id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void addAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.getTransactionBegin();
       dao.addAuthor(author);
       dao.gettransactioncommit();
	}

	@Override
	public void updateAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.getTransactionBegin();
     dao.updateAuthor(author);
     dao.gettransactioncommit();
	}

	@Override
	public void deleteAuthor(Author author) {
		// TODO Auto-generated method stub
		dao.getTransactionBegin();
        dao.deleteAuthor(author);
        dao.gettransactioncommit();
	}

	@Override
	public List<Author> getAllAuthors() {
		return dao.getAllAuthors();
	}

	

	

}
